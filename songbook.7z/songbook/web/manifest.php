<?
header('Content-Type: text/cache-manifest');
echo <<<END
CACHE MANIFEST
#v1.03
css/songbook.css
img/songbook.png
img/songbook-start.png
END;
