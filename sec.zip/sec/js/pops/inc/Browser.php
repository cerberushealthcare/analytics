<?
/**
 * Browser Pop 
 */
?>
<div id='pop-bro' class='pop' onmousedown='event.cancelBubble = true'>
  <div id='pop-bro-cap' class='pop-cap'>
    <div>
      Clicktate - Browser
    </div>
    <a href='javascript:Browser.pClose()' class='pop-close'></a>
  </div>
  <div class='pop-content' style='padding:0'>
    <iframe src='https://preproduction.newcropaccounts.com/InterfaceV7/driver.aspx' style='width:800px;height:600px;'>
    </iframe>
  </div>
</div>
