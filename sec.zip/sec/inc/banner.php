<div>
  <?php if (isset($myUid)) { ?>
    <div id="login">
      Logged in as <?=$myUid ?> | <a href=".?logout=Y">Log out</a>
    </div>
  <?php } ?>
</div>
