<?
header('Content-Type: text/cache-manifest');
echo <<<END
CACHE MANIFEST
#v1.03
css/skywatch.css
img/skywatch-splash.png
img/jet2.png
js/ui.js
END;
