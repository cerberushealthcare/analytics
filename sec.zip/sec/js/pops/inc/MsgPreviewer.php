<?
set_include_path('../../../');
/*
 * Message Previewer
 */
?>
<div id="pop-mpv" class="pop" onmousedown="event.cancelBubble = true">
  <div id="pop-mpv-cap" class="pop-cap">
    <div> 
      Clicktate - Message Viewer
    </div>
    <a href="javascript:MsgPreviewer.mpvClose()" class="pop-close"></a>
  </div>
  <div id="pop-mpv-content" class="pop-content" style='width:650px'>
    <div id="pop-mpv-nav">
      <table border="0" cellpadding="0" cellspacing="0" width="100%">
        <tr>
          <td id="mpv-nav-1">
            <a id="mpv-nav-prev" href="javascript:MsgPreviewer.mpvPrev()">
              <div id="mpv-nav-prev-div"></div>
            </a>
          </td>
          <td id="mpv-nav-2">
            <div id="mpv-nav-on-div"></div>
          </td>
          <td id="mpv-nav-3">
            <a id="mpv-nav-next" href="javascript:MsgPreviewer.mpvNext()">
              <div id="mpv-nav-next-div"></div>
            </a>
          </td>
        </tr> 
      </table>
    </div>
    <div id="pop-mpv-body">
    </div>
    <table border="0" cellpadding="0" cellspacing="0" width="100%">
      <tr>
        <td nowrap="nowrap">
          <div class="pop-cmd">
            <label>
              This message:
            </label>
            <a id="mpv-edit" href="javascript:MsgPreviewer.mpvEdit()" class="cmd note">Open in Message Editor</a>
            <!-- <span>&nbsp;</span>
            <a id="mpv-copy" href="javascript:MsgPreviewer.mpvPrint()" class="cmd print-note">Print...</a> -->
          </div>
        </td>
        <td style="width:100%">
          <div class="pop-cmd cmd-right">
            <a href="javascript:MsgPreviewer.mpvClose()" class="cmd none">&nbsp;&nbsp;&nbsp;Exit&nbsp;&nbsp;&nbsp;</a>
            <span>&nbsp;</span>
          </div>
        </td>
      </tr>
    </table>
  </div>
</div>