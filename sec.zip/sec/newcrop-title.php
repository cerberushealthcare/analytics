<html>
  <body style='background-color:#008E80;margin:5px 5px 0 0;text-align:right'>
    <a style='color:white;font-family:Arial;font-size:11pt;' href='javascript:top.close()'>Close Window</a>
  </body>
</html>