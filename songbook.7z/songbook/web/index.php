<!DOCTYPE html>
<html manifest='manifest.php'>
<head>
  <meta name='viewport' content='user-scalable=no,width=device-width,initial-scale=1.0,maximum-scale=1.0;'/>
  <meta name='apple-mobile-web-app-capable' content='yes'/>
  <meta name='apple-mobile-web-app-status-bar-style' content='black'/>
  <link rel='apple-touch-icon-precomposed' href='img/songbook.png'/>
  <link rel='apple-touch-startup-image' href='img/songbook-start.png'/>
  <link rel='stylesheet' href='css/songbook.css' media='screen,mobile' title='main' charset='utf-8'/>
  <title>My Songbook</title>
</head>
<body>
  <div id='page'>
    <div id='head'>
    </div>
    <div id='body'>
<div class='tile'>top!</div>
<div class='tile'>beta</div>
<div class='tile'>gamma</div>
<div class='tile'>delta</div>
<div class='tile'>epsilon</div>
<div class='tile'>zeta</div>
<div class='tile'>eta</div>
<div class='tile'>theta</div>
<div class='tile'>alpha</div>
<div class='tile'>beta</div>
<div class='tile'>gamma</div>
<div class='tile'>delta</div>
<div class='tile'>epsilon</div>
<div class='tile'>zeta</div>
<div class='tile'>eta</div>
<div class='tile'>theta</div>
<div class='tile'>alpha</div>
<div class='tile'>beta</div>
<div class='tile'>gamma</div>
<div class='tile'>delta</div>
<div class='tile'>epsilon</div>
<div class='tile'>zeta</div>
<div class='tile'>eta</div>
<div class='tile'>theta</div>
<div class='tile'>alpha</div>
<div class='tile'>beta</div>
<div class='tile'>gamma</div>
<div class='tile'>delta</div>
<div class='tile'>epsilon</div>
<div class='tile'>zeta</div>
<div class='tile'>eta</div>
<div class='tile'>theta</div>
    </div>
  </div>
<script>
(function(elems) {
    var cont;
    var startY;
    var idOfContent = "";
    nonbounce_touchmoveBound = false;

    var isContent = function(elem) {
        var id = elem.getAttribute("id");

        while (id !== idOfContent && elem.nodeName.toLowerCase() !== "body") {
            elem = elem.parentNode;
            id = elem.getAttribute("id");
        }

        return (id === idOfContent);
    };

    var touchstart = function(evt) {
        // Prevents scrolling of all but the nonbounce element
        if (!isContent(evt.target)) {
            evt.preventDefault();
            return false;
        }

        startY = (evt.touches) ? evt.touches[0].screenY : evt.screenY;
    };

    var touchmove = function(evt) {
        var elem = evt.target;

        var y = (evt.touches) ? evt.touches[0].screenY : evt.screenY;

        // Prevents scrolling of content to top
        if (cont.scrollTop === 0 && startY <= y) {
            evt.preventDefault();
        }

        // Prevents scrolling of content to bottom
        if (cont.scrollHeight-cont.offsetHeight === cont.scrollTop && startY >= y) {
            evt.preventDefault();
        }
    }

    if (typeof elems === "string") {
        cont = document.getElementById(elems);

        if (cont) {
            idOfContent = cont.getAttribute("id");
            window.addEventListener("touchstart", touchstart, false);
        }
    }

    if (!nonbounce_touchmoveBound) {
        window.addEventListener("touchmove", touchmove ,false);
    }
})('body');
var h = document.getElementById('head');
document.getElementById('body').style.height = (window.innerHeight - h.offsetHeight) + 'px';
</script>
</body>
</html>