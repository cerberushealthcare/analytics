<!DOCTYPE html>
<html manifest='manifest.php'>
<head>
  <meta name='viewport' content='user-scalable=no,width=device-width,initial-scale=1.0,maximum-scale=1.0;'/>
  <meta name='apple-mobile-web-app-capable' content='yes'/>
  <meta name='apple-mobile-web-app-status-bar-style' content='black'/>
  <link rel='apple-touch-icon-precomposed' href='img/jet2.png'/>
  <link rel='apple-touch-startup-image' href='img/skywatch-splash.png'/>
  <link rel='stylesheet' href='css/skywatch.css' media='screen,mobile' title='main' charset='utf-8'/>
  <script type='text/javascript' src='js/ui.js'></script>
  <title>Sky Watch</title>
</head>
<body>
  <div id='page'>
    <div id='head'>
    </div>
    <div id='body'>
    </div>
  </div>
<script>
fix_page();
</script>
</body>
</html>