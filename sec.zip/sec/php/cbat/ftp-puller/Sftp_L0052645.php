<?php
require_once 'php/data/sftp/Sftp.php';
//
class Sftp_L0052645 extends Sftp {
  //
  static $HOST = 'ssh.paml.com';
}
